public interface Function
{
    double fun(double param);
    String toString();
}
