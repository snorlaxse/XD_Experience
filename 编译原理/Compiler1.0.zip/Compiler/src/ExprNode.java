/*结点类的数据结构*/

public class ExprNode
{
    private Token token;
    private ExprNode left;
    private ExprNode right;

    public ExprNode()   // 无参构造
    {
        token = null;
        left = null;
        right = null;
    }

    public ExprNode(Token token, ExprNode left, ExprNode right)     //含参构造
    {
        this.token = token;
        this.left = left;
        this.right = right;
    }


    public void setLeft(ExprNode left)
    {
        this.left = left;
    }

    public void setRight(ExprNode right)
    {
        this.right = right;
    }

    public void setToken(Token token)
    {
        this.token = token;
    }


    public ExprNode getLeft()
    {
        return left;
    }

    public ExprNode getRight()
    {
        return right;
    }

    public Token getToken()
    {
        return token;
    }
}
