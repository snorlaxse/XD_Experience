public abstract class Function
{
    public abstract double fun(double param);
    public abstract String toString();
}
