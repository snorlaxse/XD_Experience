package PIMS;


import java.util.Date;

public interface PIMInterface{

    public void setDate(Date date);
    public String getDate();

}
